module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  theme: {
    extend: {
      keyframes: {
        'fade-in-down': { '0%': { opacity: '0', transform: 'translateY(-20px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        'spin-slow': { '0%': { transform: 'rotate(0deg)' }, '100%': { transform: 'rotate(360deg)' } },
        wiggle: { '0%, 100%': { transform: 'rotate(-3deg)' }, '50%': { transform: 'rotate(3deg)' } },
        swing: { '20%': { transform: 'translateX(5px)' }, '40%': { transform: 'translateX(-5px)' }, '60%': { transform: 'translateX(3px)' }, '80%': { transform: 'translateX(-3px)' } }
      },
      animation: {
        'fade-in-down': 'fade-in-down 4s ease-out forwards',
        'spin-slow': 'spin-slow 4s linear infinite',
        'pulse-4s': 'pulse 4s infinite',
        'shake-4s': 'shake 4s ease-in-out infinite',
        'ping-4s': 'ping 4s infinite',
        'bounce-4s': 'bounce 4s infinite',
        'wiggle-4s': 'wiggle 4s ease-in-out infinite',
        'swing-4s': 'swing 4s ease-in-out infinite'
      }
    }
  },
  plugins: []
};
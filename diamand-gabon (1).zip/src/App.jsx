import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import ProfilJoueur from './pages/ProfilJoueur';
import VideoLive from './pages/VideoLive';
import BlogList from './pages/BlogList';
import BlogPost from './pages/BlogPost';
import ChatCommunity from './pages/ChatCommunity';
import ConversationsList from './pages/ConversationsList';
import PrivateChat from './pages/PrivateChat';
import AdminDashboard from './pages/AdminDashboard';
import AdminBlogPage from './pages/AdminBlogPage';
import NewEditBlogPost from './pages/NewEditBlogPost';
import AdminCampaigns from './pages/AdminCampaigns';
import TermsOfUse from './pages/TermsOfUse';
import PrivacyPolicy from './pages/PrivacyPolicy';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/profil" element={<ProfilJoueur />} />
        <Route path="/videos" element={<VideoLive />} />
        <Route path="/blog" element={<BlogList />} />
        <Route path="/blog/:id" element={<BlogPost />} />
        <Route path="/chat/community" element={<ChatCommunity />} />
        <Route path="/chat/prive" element={<ConversationsList />} />
        <Route path="/chat/prive/:id" element={<PrivateChat />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/blog" element={<AdminBlogPage />} />
        <Route path="/admin/blog/new" element={<NewEditBlogPost />} />
        <Route path="/admin/blog/edit/:id" element={<NewEditBlogPost />} />
        <Route path="/admin/campaigns" element={<AdminCampaigns />} />
        <Route path="/terms" element={<TermsOfUse />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
      </Routes>
    </BrowserRouter>
  );
}